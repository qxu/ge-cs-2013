package com.csc2013;

public class Consumable {

}